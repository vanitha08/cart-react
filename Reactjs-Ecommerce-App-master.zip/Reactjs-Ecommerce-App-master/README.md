E-commerce Platform using Reactjs and Firebase(Hosting)
https://reactjs-commerce.netlify.app

![projekt1](https://user-images.githubusercontent.com/58092596/116826790-0d35b600-ab96-11eb-9716-0bd9ecf2a68c.png)
Details:
1. Users can add  products to the cart and delete from cart
2. Users can checkout cart products using Paypal or Debit Card
3. All products data are stored in localstorage =  Soon in Firebase

